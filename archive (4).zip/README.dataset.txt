# x-ray rheumatology > release
https://universe.roboflow.com/object-detection/x-ray-rheumatology

Provided by Roboflow
License: CC BY 4.0

